@echo off


echo [?] Checking permissions.
echo.

net session >nul 2>&1
if %errorlevel% == 0 (
    echo [*] Administrator granted
) else (
    echo [!] Please run the installer as administrator.
    pause
    exit /b
)

echo.

echo [WARNING] If luma is not in the user directory. The installation will fail.

echo.

pause

echo [*] Installing..


set CMD_DIR=%SystemRoot%


set CMD_NAME=luma


set TARGET=%USERPROFILE%\luma\luma.bat


echo @"%TARGET%" %%* > "%CMD_DIR%\%CMD_NAME%.bat"

echo [*] Installed luma command


echo [*] Registering file extension..


REG ADD "HKCR\.luma" /ve /d "LumaFile" /f
REG ADD "HKCR\LumaFile" /ve /d "Luma File" /f
REG ADD "HKCR\LumaFile\Shell\Open\Command" /ve /d "\"%USERPROFILE%\luma\luma.bat\" \"%%1\"" /f

cls

echo [*] Registered file extension .luma

echo.
echo [!] Do not move Luma out of your user folder.
pause