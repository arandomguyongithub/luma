@echo off

net session >nul 2>&1
if %errorlevel% == 0 (
    start %USERPROFILE%\luma\uninstaller\main.luma
) else (
    echo [!] Please run the uninstaller as administrator.
    pause
)