cd %USERPROFILE%\luma
lua.exe luma.lua %*
cd %USERPROFILE%
cls