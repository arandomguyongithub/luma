---@diagnostic disable: need-check-nil


local classes = {
    file = {
        path = "",
        isFile = function()
            return true
        end,
        isFolder = function()
            return false
        end
    },

    directory = {
        path = "",
        isFile = function()
            return false
        end,
        isFolder = function()
            return true
        end


    },

    script = {
        getParent = function(fileArg)
            local path = fileArg or debug.getinfo(1, "S").source:sub(2)
            path = path:gsub("\\", "/")
            local parent = path:match("(.+)/[^/]+$")
            return parent
        end

    }
}

local function wait(s)
    local start = os.clock()
    while os.clock() - start < s do

    end
end




classes.file.rename = function(name)
    local self = classes.file
    os.execute("rename " .. self.path .. " " .. name)
end

classes.file.move = function(destination)
    local self = classes.file
    os.execute("move /y " .. self.path .. " " .. destination)
end

classes.file.remove = function()
    local self = classes.file
    os.execute("DEL /Q " .. self.path)
end


classes.directory.getFiles = function(instance)
    local handle = io.popen('dir /b "' .. instance.path .. '"')
    local result = handle:read("*a")
    handle:close()

    local files = {}
    for filename in result:gmatch("[^\r\n]+") do
        table.insert(files, filename)
    end
    return files
end


classes.directory.findFirstFile = function(name)
    local self = classes.directory
    for _, file in pairs(self.getFiles()) do
        if file == name then
            return file or true
        end
    end
end

local function getType(t)
    local copy = {}
    for k, v in pairs(t) do
        copy[k] = v
    end
    return copy
end


local function toDirectory(path)
    local dir = getType(classes.directory)
    dir.path = path

    dir.fileAdded = getType(classes.directory.fileAdded)
    dir.fileAdded._dir = dir

    dir.fileRemoved = getType(classes.directory.fileRemoved)
    dir.fileRemoved._dir = dir

    return dir
end



local env = {
    script = classes.script,
    sys = {
        mkdir = function(path)
            return toDirectory(path)
        end,

        execute = function(cmd)
            os.execute(cmd)
        end,

        getVariable = function(variable)
            local handle = io.popen("echo %" .. variable .. "%")
            local result = handle:read("*a")
            handle:close()
            result = result:gsub("[\r\n]+", "")
            return result
        end,

        readFile = function(path)
            local f, err = io.open(path, "r")
            if not f then
                return nil, err
            end
            local content = f:read("*a")
            f:close()
            return content
        end,


        writeFile = function(path, content)
            os.execute("echo " .. content .. " > " .. path)
        end,

        start = function(program)
            os.execute("start " .. program)
        end,

        kill = function(process)
            os.execute("taskkill /IM " .. process .. " /F")
        end,

        remove = function(path)
            os.execute("DEL /Q " .. path)
        end,

        popup = function(title, message)
            os.execute('echo x=msgbox("' .. message .. '", 0+16, "' .. title .. '") > temp.vbs')
            os.execute('echo WScript.Echo x >> temp.vbs')

            local handle = io.popen('cscript //nologo temp.vbs')
            local result = handle:read("*a")
            handle:close()

            local start = os.clock()
            while os.clock() - start < 1 do end
            os.execute("DEL /Q temp.vbs")
        end,

        confirm = function(title, message)
    local function escapeQuotes(str)
        return (str or ""):gsub('"', '""')
    end

    local tempFolder = os.getenv("TEMP") or "."
    local tempFile = tempFolder .. "\\luma_confirm_" .. tostring(os.time()) .. ".vbs"

    local file = assert(io.open(tempFile, "w"))
    file:write(string.format([[
response = MsgBox("%s", vbYesNo + vbQuestion, "%s")
WScript.Echo response
]], escapeQuotes(message), escapeQuotes(title or "Message")))
    file:close()

    local handle = assert(io.popen('cscript //nologo "' .. tempFile .. '"'))
    local result = handle:read("*a")
    handle:close()

    os.remove(tempFile)

    result = result:match("%d+")
    local code = tonumber(result)

    if code == 6 then
        return true
    elseif code == 7 then
        return false
    else
        return nil
    end
end,
        
        temp = function(extension, content)
            os.execute("echo " .. content .. " > temp." .. extension)
            os.execute("start temp." .. extension)
            local start = os.clock()
            while os.clock() - start < 2 do end
            os.execute("DEL /Q temp." .. extension)
        end
    },


    version = function()
        return "Luma v1.0"
    end,

    toFile = function(path)
        local converted = getType(classes.file)
        converted.path = path
        return converted
    end,

    toDirectory = toDirectory,


    task = {
        wait = wait
    },



    -- lua defaults
    print = print,
    table = table,
    string = string,
    math = math,
    pairs = pairs,
    ipairs = ipairs,
    pcall = pcall,
    xpcall = xpcall,
    tostring = tostring,
    tonumber = tonumber
}


env["setenv"] = function(key, value)
    env[key] = value
end

env["getenv"] = function(key)
    return env[key]
end

env["loadstring"] = function(source, chunkname, custom_env)
    if chunkname == nil then
        chunkname = "luma"
    end
    if custom_env == nil then
        custom_env = env
    end

    return load(source, chunkname, "t", custom_env)
end

env.task.spawn = function(source)
    local function thread(x)
        load(x, "luma", "t", env)()
    end
    local created = coroutine.create(thread)
    coroutine.resume(created, source)
end

classes.script.getFile = function()
    return env.toFile(classes.script._file)
end




classes.script.isAdmin = function()
    local handle = io.popen([[powershell -Command "[bool](([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))"]])
    local result = handle:read("*a")
    handle:close()

    result = result:match("%S+")
    return result == "True"
end








classes.script.requestAdmin = function()
    local ok = env.sys.confirm("Administrator", "This program is requesting administrator. Grant?")
    if not ok then return false end

    local filePath = classes.script.getFile()
    filePath = filePath.path

    local cmd = [[powershell -Command "Start-Process '%USERPROFILE%\luma\luma.bat' -ArgumentList ']] .. filePath .. [[' -Verb RunAs"]]

    os.execute(cmd)
    return true
end












classes.directory.fileAdded = {
    _callbacks = {},
    _watching = false,

    _fire = function(self, file)
        for _, callback in ipairs(self._callbacks) do
            callback(file)
        end
    end,

_startWatching = function(self)
    local dir = self._dir
    local knownFiles = {}
    for _, f in ipairs(dir:getFiles()) do
        knownFiles[f] = true
    end

    env.task.spawn(function()
        while true do
            local currentFiles = {}
            for _, f in ipairs(dir:getFiles()) do
                currentFiles[f] = true
                if not knownFiles[f] then
                    self:_fire(f)
                end
            end
            knownFiles = currentFiles
            env.task.wait(1)
        end
    end)
end


}

function classes.directory.fileAdded:connect(func)
    table.insert(self._callbacks, func)

    if not self._watching then
        self:_startWatching()
        self._watching = true
    end
end


















classes.directory.fileRemoved = {
    _callbacks = {},
    _watching = false,

    _fire = function(self, file)
        for _, callback in ipairs(self._callbacks) do
            callback(file)
        end
    end,

_startWatching = function(self)
    local dir = self._dir
    local knownFiles = {}
    for _, f in ipairs(dir:getFiles()) do
        knownFiles[f] = true
    end

    env.task.spawn(function()
        while true do
            local currentFiles = {}
            for _, f in ipairs(dir:getFiles()) do
                currentFiles[f] = true
            end

            for f in pairs(knownFiles) do
                if not currentFiles[f] then
                    self:_fire(f)
                end
            end

            knownFiles = currentFiles
            env.task.wait(1)
        end
    end)
end



}

function classes.directory.fileRemoved:connect(func)
    table.insert(self._callbacks, func)

    if not self._watching then
        self:_startWatching()
        self._watching = true
    end
end






env.sys["input"] = function(prompt)
    prompt = prompt or ""
    local folder = env.script.getParent()
    local inputFile = folder .. "\\luma_input.txt"
    local tempBat = folder .. "\\temp_input.bat"
    local tempPy  = folder .. "\\luma_input.py"

    local f = io.open(tempPy, "w")
    f:write(string.format([[
a = input(%q)
with open(%q, "w") as f:
    f.write(a)
]], prompt, inputFile))
    f:close()

    local fBat = io.open(tempBat, "w")
    fBat:write(string.format('python "%s"\nexit\n', tempPy))
    fBat:close()

    os.execute('start "" "' .. tempBat .. '"')

    local handle
    while true do
        handle = io.open(inputFile, "r")
        if handle then break end
        env.task.wait(0.1)
    end

    local result = handle:read("*a")
    handle:close()

    os.remove(inputFile)
    os.remove(tempPy)
    os.remove(tempBat)

    return result
end








local function fileExists(path)
    local f = io.open(path, "r")
    if f then
        f:close()
        return true
    else
        return false
    end
end



local input = arg[1]
if not input then
    error("argument was not passed")
    return "no arguments passed"
end

if fileExists(input) then
    classes.script._file = input
end

local pluginsFolder = toDirectory(env.sys.getVariable("USERPROFILE") .. "\\luma\\plugins")
for _, filename in pairs(classes.directory.getFiles(pluginsFolder)) do
    if filename:sub(-5):lower() == ".luma" then
        local fullPath = pluginsFolder.path .. "\\" .. filename
        local content, err = env.sys.readFile(fullPath)
        if not content then
            error("Cannot read plugin '" .. filename .. "': " .. (err or "unknown error"))
        end

        local chunk, loadErr = load(content, filename, "t", env)
        if not chunk then
            error("Error loading plugin '" .. filename .. "': " .. loadErr)
        end
        chunk()
    end
end





if fileExists(input) then
    local chunk, err = loadfile(input, "t", env)
    if not chunk then
        error("error loading file: " .. err)
    end
    chunk()
else
    local chunk, err = load(input, "luma", "t", env)
    if not chunk then
        error("error loading code string: " .. err)
    end
    chunk()
end